using System;
using System.Collections.Generic;

namespace EstudandoCSharp
{
    class Funcoes{
        public int operacao{get;set;}
      
        public void mostrarMenu(){
            Console.WriteLine("1 - Adicionar Livro");
            Console.WriteLine("2 - Mostrar Livros");
            Console.WriteLine("3 - Sair");
        }

       public int escolherOperacao(){
           Console.WriteLine("Escolha uma operacao: ");
           operacao = int.Parse(Console.ReadLine());
          return operacao;
       }

       public void executarOperacao(Biblioteca biblioteca){
         if (operacao == 1){
             biblioteca.AdicionarLivro();
         }else if (operacao == 2){
             biblioteca.mostrarLivros();
         }else if (operacao == 3){
             Console.WriteLine("Saindo...");
            return;
         }
       }
    }
}