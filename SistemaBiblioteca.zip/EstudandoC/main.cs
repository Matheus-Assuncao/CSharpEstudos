using System; 
using EstudandoCSharp;
class Program {
  public static void Main (string[] args) {
    Biblioteca biblioteca = new Biblioteca();
    Funcoes funcoes = new Funcoes();
    while (true){
      funcoes.mostrarMenu();
      funcoes.escolherOperacao();
      funcoes.executarOperacao(biblioteca);
    }
  }
}

