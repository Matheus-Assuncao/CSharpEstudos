using System;
namespace EstudandoCSharp
{

  class Livro{
      public string Titulo {get; set;}
      public string Autor {get; set;}
      public String Ano {get; set;}
      public string Editora {get; set;}
  
     public void MostrarDetalhes(){
         Console.WriteLine("Titulo: " + Titulo);
         Console.WriteLine("Autor: " + Autor);
         Console.WriteLine("Ano: " + Ano);
         Console.WriteLine("Editora: " + Editora);
     }
  
    public void AdicionarLivro(){
      AdicionaTitulo();
      AdicionaAutor();
      AdicionaAno();
      AdicionaEditora();
      Console.WriteLine("Livro adicionado com sucesso!");
    }
  
    private void AdicionaTitulo(){
        Console.WriteLine("Adicionar titulo: ");
        Titulo = Console.ReadLine();
    }
  
    private void AdicionaAutor(){
        Console.WriteLine("Adicionar autor: ");
        Autor = Console.ReadLine();;
    }
  
    private void AdicionaAno(){
        Console.WriteLine("Adicionar ano: ");
        Ano = Console.ReadLine();
    }
  
    private void AdicionaEditora(){
        Console.WriteLine("Adicionar editora: ");
        Editora = Console.ReadLine();
    }
  }
}
