using System;
using System.Collections.Generic;
using EstudandoCSharp;

namespace EstudandoCSharp
{

  class Biblioteca{
    public List<Livro> Livros = new List<Livro>();
  
  
    public void AdicionarLivro(){
        Livro livro = new Livro();
        livro.AdicionarLivro();
        Livros.Add(livro);
    }
  
  
    public void mostrarLivros(){
        Livros.ForEach(livro => livro.MostrarDetalhes());
    }
  }
} 
